﻿namespace OpcUaImitator
{
    public class Class1
    {

    }
}
