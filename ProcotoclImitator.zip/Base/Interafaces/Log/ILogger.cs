﻿namespace Base.Interafaces.Log
{
    public interface ILogger
    {
        event Action<string>? LogMessage;
    }
}
